from django.shortcuts import render
from django.shortcuts import redirect
from . import models
from . import forms
import hashlib
# Create your views here.

def hash_code(s, salt='mysite'):# 加点盐
    h = hashlib.sha256()
    s += salt
    h.update(s.encode())  # update方法只接收bytes类型
    return h.hexdigest()

def index(request):
    return render(request, 'index.html')


def login(request):
    if request.method == 'POST':
        login_form = forms.UserForm(request.POST)
        message = '请检查填写的内容！'
        if login_form.is_valid():
            username = login_form.cleaned_data.get('username')
            password = login_form.cleaned_data.get('password')

            try:
                user = models.Customer.objects.get(cname=username)
            except :
                message = '用户不存在！'
                return render(request, 'login.html', locals())

            if user.password == password:
                request.session['is_login'] = True
                request.session['user_tel'] = user.ctel
                request.session['user_name'] = user.cname
                return redirect('/index/')

            else:
                message = '密码不正确！'
                return render(request, 'login.html', locals())
        else:
            return render(request, 'login.html', locals())

    login_form = forms.UserForm()
    return render(request, 'login.html', locals())


def register(request):
    if request.session.get('is_login', None):
        return redirect('/index/')

    if request.method == 'POST':
        register_form = forms.RegisterForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():
            username = register_form.cleaned_data.get('username')
            ctel = register_form.cleaned_data.get('ctel')
            password1 = register_form.cleaned_data.get('password1')
            password2 = register_form.cleaned_data.get('password2')

            if len(username) < 2 or len(username) > 25:
                message = '用户名字符长度必须大于等于2并小于等于25！'
                return render(request, 'register.html', locals())
            if len(password1) < 6 or len(password1) > 20:
                message = '密码长度必须大于等于6并小于等于20！'
                return render(request, 'register.html', locals())
            if password1 != password2:
                message = '两次输入的密码不同！'
                return render(request, 'register.html', locals())
            else:
                same_name_user = models.Customer.objects.filter(cname=username)
                if same_name_user:
                    message = '用户名已经存在'
                    return render(request, 'register.html', locals())

                new_user = models.Customer()
                new_user.cname = username
                new_user.ctel = ctel
                new_user.password = password1
                new_user.save()

                return redirect('/login/')
        else:
            return render(request, 'register.html', locals())
    register_form = forms.RegisterForm()
    return render(request, 'register.html', locals())



def logout(request):
    if not request.session.get('is_login', None):
        return redirect('/login/')

    request.session.flush()
    # del request.session['is_login']
    return redirect("/login/")

def changepassword(request):
    if request.method == 'POST':
        change_form = forms.ChangepasswordForm(request.POST)
        message = ''
        if change_form.is_valid():
            username = change_form.cleaned_data.get('username')
            oldpassword = change_form.cleaned_data.get('oldpassword')
            newpassword1 = change_form.cleaned_data.get('newpassword1')
            newpassword2 = change_form.cleaned_data.get('newpassword2')

            try:
                user = models.Customer.objects.get(cname=username)
            except :
                message = '用户不存在！'
                return render(request, 'changepassword.html', locals())
            if user.password == oldpassword:
                if len(newpassword1) < 6 or len(newpassword1) > 20:
                    message = '密码长度必须大于等于6并小于等于20！'
                    return render(request, 'changepassword.html', locals())
                if newpassword1 != newpassword2:
                    message = '两次输入的密码不同！'
                    return render(request, 'changepassword.html', locals())
                user.password = newpassword1
                user.save()
                return render(request, 'index.html', locals())
            else:
                message = '密码不正确！'
                return render(request, 'changepassword.html', locals())
        else:
            return render(request, 'login.html', locals())

    change_form = forms.ChangepasswordForm()
    return render(request, 'changepassword.html', locals())

def view_cart(request):
    pass
