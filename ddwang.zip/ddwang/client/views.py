from django.http import JsonResponse
from django.shortcuts import render
from django.shortcuts import redirect
from django.views.decorators import csrf
from datetime import datetime
from bookstore import models
from django.db.models import Q
import json
from django.http import HttpResponse
from client import forms
from django.contrib import messages
from django.forms.models import model_to_dict

def index(request):
    context = {}
    context['content'] = models.Book.objects.filter(on_sale='Y')
    context['heading'] = 'ddwang'
    if request.session.get('is_login', None):
        return render(request, "client/home.html", context)
    return render(request, 'client/index.html', context)


def home(request):
    context = {}
    context['content'] = models.Book.objects.filter(on_sale='Y')
    return render(request, 'client/home.html', context)


def book_detail(request, book_id):
    cur_book = models.Book.objects.get(book_id=book_id)
    assert isinstance(cur_book, object)
    context = {'cur_book': cur_book}
    return render(request, 'client/bookdetail.html', context)


def search(request):
    if request.method == 'GET':
        query = request.GET.get('bookname')

        if query is not None:
            lookups = Q(title__icontains=query)

            results = models.Book.objects.filter(lookups).distinct()

            context = {'results': results}

            return render(request, 'client/search.html', context)

        else:
            return render(request, "client/search.html")

    else:
        return render(request, 'client/search.html')


def register(request):
    if request.session.get('is_login', None):
        return redirect("client:home")

    if request.method == 'POST':
        register_form = forms.RegisterForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():
            username = register_form.cleaned_data.get('username')
            ctel = register_form.cleaned_data.get('ctel')
            password1 = register_form.cleaned_data.get('password1')
            password2 = register_form.cleaned_data.get('password2')

            if len(username) < 2 or len(username) > 25:
                message = '用户名字符长度必须大于等于2并小于等于25！'
                return render(request, 'client/register.html', locals())
            if len(password1) < 6 or len(password1) > 20:
                message = '密码长度必须大于等于6并小于等于20！'
                return render(request, 'client/register.html', locals())
            if password1 != password2:
                message = '两次输入的密码不同！'
                return render(request, 'client/register.html', locals())
            else:
                same_name_user = models.Customer.objects.filter(cname=username)
                if same_name_user:
                    message = '用户名已经存在'
                    return render(request, 'client/register.html', locals())

                new_user = models.Customer()
                new_user.cname = username
                new_user.ctel = ctel
                new_user.password = password1
                new_user.save()
                messages.success(request, '注册成功')
                return redirect("client:login")
        else:
            return render(request, 'client/register.html', locals())
    register_form = forms.RegisterForm()
    return render(request, "client/register.html", locals())


def login(request):
    if request.method == 'POST':
        login_form = forms.UserForm(request.POST)

        if login_form.is_valid():
            username = login_form.cleaned_data.get('username')
            password = login_form.cleaned_data.get('password')

            try:
                user = models.Customer.objects.get(cname=username)
            except:
                messages.error(request, '用户不存在！')
                return render(request, 'client/login.html', locals())

            if user.password == password:
                request.session['is_login'] = True
                request.session['user_tel'] = user.ctel
                request.session['user_name'] = user.cname
                request.session.set_expiry(60 * 30)  # 30min
                messages.success(request, '登录成功')

                return redirect("client:home")

            else:
                messages.error(request, '密码错误！')
                return render(request, 'client/login.html', locals())
        else:
            return render(request, 'client/login.html', locals())

    login_form = forms.UserForm()
    return render(request, 'client/login.html', locals())


def logout(request):
    context = {}
    context['content'] = models.Book.objects.all()
    context['heading'] = 'ddwang'
    if not request.session.get('is_login', None):
        return redirect("index")

    request.session.flush()
    # del request.session['is_login']
    return redirect("index")

def changepassword(request):
    if request.method == 'POST':
        change_form = forms.ChangepasswordForm(request.POST)
        message = ''
        if change_form.is_valid():
            username = change_form.cleaned_data.get('username')
            oldpassword = change_form.cleaned_data.get('oldpassword')
            newpassword1 = change_form.cleaned_data.get('newpassword1')
            newpassword2 = change_form.cleaned_data.get('newpassword2')

            try:
                user = models.Customer.objects.get(cname=username)
            except:
                message = '用户不存在！'
                return render(request, 'client/changepassword.html', locals())
            if user.password == oldpassword:
                if len(newpassword1) < 6 or len(newpassword1) > 20:
                    message = '密码长度必须大于等于6并小于等于20！'
                    return render(request, 'client/changepassword.html', locals())
                if newpassword1 != newpassword2:
                    message = '两次输入的密码不同！'
                    return render(request, 'client/changepassword.html', locals())
                user.password = newpassword1
                user.save()
                return redirect("index")
            else:
                message = '密码不正确！'
                return render(request, 'client/changepassword.html', locals())
        else:
            return redirect("client:login")

    change_form = forms.ChangepasswordForm()
    return render(request, 'client/changepassword.html', locals())


# @login_required(login_url='/login/', redirect_field_name='next')
def addtocart(request, book_id):
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)

    username = request.session['user_name']
    cur_user = models.Customer.objects.get(cname=username)
    cur_book = models.Book.objects.get(book_id=book_id)

    item = {
        'book_id': cur_book.book_id,
        'title': cur_book.title,
        'quantity': 1,
        'price': cur_book.price
    }

    if cur_user:
        usession = cur_user.session
        # return HttpResponse(usession)
        if usession:
            cart = json.loads(usession)
        else:
            cart = {}
        if str(cur_book.book_id) not in cart.keys():
            cart[cur_book.book_id] = item
        else:
            cart[str(cur_book.book_id)]['quantity'] = 1 + int(cart[str(cur_book.book_id)]['quantity'])

        cart_string = json.dumps(cart)
        cur_user.session = cart_string
        cur_user.is_active = True
        cur_user.last_active_time = datetime.now()
        cur_user.save()
        cur_user.refresh_from_db()
        messages.success(request, "添加成功")
        return redirect('client:home')
        # return render(request, 'add_success.html')
    return render(request, 'client/index.html')


def cart(request):
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)
    book_quantity = None
    book_id = None
    if request.method == 'POST':
        book_quantity = request.POST.get('book_quantity')
        book_id = request.POST.get('book_id')

    username = request.session['user_name']
    cur_user = models.Customer.objects.get(cname=username)
    if cur_user:
        usession = cur_user.session
        if usession:
            cart = json.loads(usession)
        else:
            cart = {}
            messages.warning(request, '购物车为空')
            return redirect('client:home')
    if book_id and book_quantity:
        cart[str(book_id)]['quantity'] = int(book_quantity)
    context = {}
    # items应改为购物车中的内容
    # items = models.Orderdetail.objects.filter(order=order_id)
    items = cart
    # items = models.Orderdetail.objects.filter(book_id__lt=2)
    context['heading'] = "购物车"
    context['content'] = items
    context['buttons'] = "<button><a href=\"/client/info\">结算</a></button>"
    total = 0
    for key, value in items.items():
        total += (int(value['quantity']) * int(value['price']))
    context['total'] = total
    return render(request, 'client/cart.html', context)

def modifycart_confirm(request):
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)

    book_id = request.POST.get('book_id')
    book_quantity = request.POST.get('book_quantity')
    user = request.session['user_name']
    cur_user = models.Customer.objects.get(cname=user)
    if cur_user:
        usession = cur_user.session
        if usession:
            cart = json.loads(usession)
        else:
            cart = {}
            messages.warning(request, '购物车为空')
            return redirect('client:home')
    if book_id and book_quantity:
        cart[str(book_id)]['quantity'] = int(book_quantity)
    cart_string = json.dumps(cart)
    cur_user.session = cart_string
    cur_user.is_active = True
    cur_user.last_active_time = datetime.now()
    cur_user.save()
    cur_user.refresh_from_db()
    messages.success(request, "保存成功")
    return redirect('client:cart')
    
def search_failed(request):
    messages.error(request, '这本书我们还没上架～～～或者没有！看看别的吧')
    return redirect('client:home')

def info(request):
    context = {}
    context['heading'] = "结算中心"

    return render(request, 'client/info.html', context)


def info_post(request):    
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)

    context = {}
    cus = request.session['user_name']
    cus = models.Customer.objects.get(cname=cus)
    if not cus.session:
        messages.warning(request, '购物车为空')
        return redirect('client:home')
    cart = json.loads(cus.session)
    items = cart.keys()
    if request.POST:
        if not request.POST['address']:
            messages.error(request, '收货地址不能为空')
            return redirect('client:info')
        if not request.POST['tel']:
            messages.error(request, '收货号码不能为空')
            return redirect('client:info')
        context['heading'] = "订单提交成功！"
        # request.POST['address']
        context['content'] = '还有<span id=\"countdown\">3</span>秒跳转至订单详情页面...'

        # get the infomation from the current cart

        # insert order information into the database
        order = models.Order.objects.create(customer=cus, order_time=datetime.now(), address=request.POST['address'],
                                    ctel=request.POST['tel'])
        # insert order_detail information into the database
        oid = order.oid
        
        context['id']=oid
        for item in items:
            bid = int(item)
            q = int(cart[item]['quantity'])
            try:
                models.Orderdetail.objects.create(order_id=oid, book_id=bid, quantity=q)
            except models.ValidationError as err:
                messages.error(request, str(err))
                order = models.Order.objects.get(oid=oid)
                order.delete()
                return redirect('client:home')
    cus.session = ''
    cus.save()
    return render(request, 'client/pageJump.html', context)


def order(request, id):
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)
    
    context = {}
    context['heading'] = "订单详情"
    order_id = int(id)
    order_data = models.Order.objects.get(oid=order_id)
    order_detail = models.Orderdetail.objects.filter(order=order_id)
    
    context['content'] = order_detail
    
    context['total'] = order_data.order_amount()
    context['detail'] = order_data

    if order_data.type == 'N':
        return redirect('client:return', id)

    if order_data.type == 'Y' and order_data.the_state_of_order() != 'closed':
        context['buttons'] = "<button><a href=\"/client/confirm/" + id + "\">确认收货</a></button>"
        if order_data.the_state_of_order() != 'goods on the way':
            context['buttons'] += "<button><a href=\"/client/return/" + id + "\">我要退货</a></button>"
    
    return render(request, 'client/hello.html', context)


def return_page(request, id):
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)
    context = {}
    context['heading'] = "退款订单详情"

    # get the order details
    cus = request.session['user_name']
    order_id = int(id)
    order_data = models.Order.objects.get(oid=order_id)
    order_detail = models.Orderdetail.objects.filter(order=order_id)

    context['content'] = order_detail
    context['total'] = order_data.order_amount()
    context['detail'] = order_data

    # if the user wants to return the books before they're delivered, set the sendtime and closetime of the current order
    if order_data.the_state_of_order() == 'not delivered yet':
        order_data.sendtime = datetime.now()
        order_data.closetime = datetime.now()
        order_data.save()
        return render(request, "client/hello.html", context)
    else:  # otherwise, create a return order

        cus = models.Customer.objects.get(cname=cus)
        neworder = models.Order.objects.create(customer=cus, order_time=datetime.now(), type='N')
        new_order_id = neworder.oid
        for item in order_detail:
            models.Orderdetail.objects.create(order_id=new_order_id, book_id=item.book_id, quantity=item.quantity)
        
        order_data = models.Order.objects.get(oid=new_order_id)
        order_detail = models.Orderdetail.objects.filter(order=new_order_id)
        context['content'] = order_detail
        context['total'] = order_data.order_amount()
        context['detail'] = order_data
        context['buttons'] = "<button><a href=\"/client/return_order/" + str(new_order_id) + "\">我已退款发货</a></button>"

    return render(request, "client/hello.html", context)


def return_order(request, id):
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)
    context = {}
    context['heading'] = "退款订单详情"

    # get the order details
    order_id = int(id)
    order_data = models.Order.objects.get(oid=order_id)
    order_data.sendtime = datetime.now()
    order_data.save()
    order_detail = models.Orderdetail.objects.filter(order=order_id)

    context['content'] = order_detail
    context['total'] = order_data.order_amount()
    context['detail'] = models.Order.objects.get(oid=order_id)

    return render(request, 'client/hello.html', context)


def confirm(request,id):
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)

    context = {}
    context['heading'] = "订单详情"

    # get the order details
    order_id = int(id)
    order_data = models.Order.objects.get(oid=order_id)
    order_data.closetime = datetime.now()
    try:
        order_data.save()
    except models.ValidationError as err:
        messages.error(request, str(err))
        return redirect('client:order', id)
    order_detail = models.Orderdetail.objects.filter(order=order_id)

    context['content'] = order_detail
    context['total'] = order_data.order_amount()
    context['detail'] = order_data = models.Order.objects.get(oid=order_id)

    context['buttons'] = "<button><a href=\"/client/return/" + id + "\">我要退货</a></button>"
    return render(request, "client/hello.html", context)

def order_list(request):
    if 'user_name' not in request.session.keys():
        form = forms.UserForm()
        context = {}
        context['login_form'] = form
        messages.warning(request, "登录超时")
        return render(request, "client/login.html", context)

    context = {}
    context['heading'] = "我的订单"
	# get information of the current customer
    username = request.session['user_name']
    cur_user = models.Customer.objects.get(cname=username)

    my_order = models.Order.objects.filter(customer=cur_user)
    my_order_list = []
    for each in my_order:
    	each_order = model_to_dict(each)
    	each_order['url'] = "/client/order/" + str(each_order['oid']) + "/"
    	each_order['total'] = each.order_amount()
    	each_order['state'] = each.the_state_of_order()
    	each_order['details'] = []
    	order_detail = models.Orderdetail.objects.filter(order=each_order['oid'])
    	for each_item in order_detail:
    		temp = {
    			'book_title': each_item.book.title,
    			'book_price': each_item.book.price,
    			'quantity': each_item.quantity
    		}
    		each_order['details'].append(temp)
    	my_order_list.append(each_order)

    context['content'] = my_order_list
    return render(request, "client/orderlist.html", context)

