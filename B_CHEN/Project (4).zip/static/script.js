$(document).ready(function(){
    function refresh(){

    }
})